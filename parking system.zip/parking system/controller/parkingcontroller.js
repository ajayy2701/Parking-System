const Parking=require('../models/parking')


exports.dashboard=(req,res)=>{
    try{
    username=req.session.username
    res.render('parkingdashboard.ejs',{username})
    }catch(error){
        console.log(error.message)
    }
}


exports.addform=(req,res)=>{
    try{
    username=req.session.username
    res.render('entryform.ejs',{username,message:''})
    }catch(error){
        console.log(error.message)
    }
}

exports.add=(req,res)=>{
    try{
    const{vno,vtype}=req.body
    const record=new Parking({vno:vno.toUpperCase(),vtype:vtype})
    record.save()
    //console.log(record)
    res.render('entryform.ejs',{username,message:'Entry Done'})
    }catch(error){
        console.log(error.message)
    }
}

exports.out=async(req,res)=>{
    try{
    username=req.session.username
    const record=await Parking.find().sort({status:1})
     const totalvehicle=await Parking.count()
     const outv=await Parking.count({status:'OUT'})
     const inv=await Parking.count({status:'IN'})
    res.render('out.ejs',{username,record,totalvehicle,outv,inv})
}catch(error){
    console.log(error.message)
}
}

exports.update=async(req,res)=>{
    try{
    const id=req.params.id
    
    let outTime=new Date()
    const record=await Parking.findById(id)
    const totalTime=(outTime-(record.vin))/(1000*60*60)
    console.log(typeof(totalTime))

    let amount=null
    if(record.vtype=="2w"){
        amount=totalTime*20
    }
    
    else if(record.vtype=="3w"){
        amount=totalTime*50
    }

    else if(record.vtype=="4w"){
        amount=totalTime*80
    }

    else if(record.vtype=="hv"){
        amount=totalTime*150
    }

    else if(record.vtype=="lv"){
        amount=totalTime*120
    }

    else{
        amount=totalTime*100
    }

     if(amount<=30){
        amount=15
    }

    await Parking.findByIdAndUpdate(id,{vout:outTime,amount:Math.round(amount),status:'OUT',totaltime:Math.round(totalTime)})
    res.redirect('/out')
}catch(error){
    console.log(error.message)
}
}

exports.print=async(req,res)=>{
    try{
    const id=req.params.id
    
    const record=await Parking.findById(id)
    res.render('print.ejs',{record})
    console.log(record)
}catch(error){
    console.log(error.message)
}
}


exports.ref=(req,res)=>{
    try{
    res.redirect('/add')
}catch(error){
    console.log(error.message)
}
}