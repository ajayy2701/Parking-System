const Reg=require('../models/reg')



exports.homepage=(req,res)=>{
    res.render('login.ejs',{message:''})
}


exports.logincheck=async(req,res)=>{
    const{us,pass}=req.body
    const usercheck=await Reg.findOne({username:us})
    if(usercheck!==null){
        if(usercheck.password==pass){
            req.session.username=us
            req.session.isAuth=true
        res.redirect('/parkingdashbord')
        }else{
            res.render('login.ejs',{message:'wrong credentails'})
        }
    }
    else{
        res.render('login.ejs',{message:'wrong credentails'})
    }
}

exports.logout=(req,res)=>{
    req.session.destroy()
    res.redirect('/')
}