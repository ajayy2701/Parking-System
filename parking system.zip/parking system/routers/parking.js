const router=require('express').Router()
const regc=require('../controller/regcontroller')
const parkingc=require('../controller/parkingcontroller')
const session=require('../helpers/session')

router.get('/',regc.homepage)

router.post('/',regc.logincheck)

router.get('/parkingdashbord',session,parkingc.dashboard)
router.get('/logout',session,regc.logout)
router.get('/add',session,parkingc.addform)
router.post('/add',parkingc.add)
router.get('/out',session,parkingc.out)
router.get('/update/:id',session,parkingc.update)

router.get('/print/:id',session,parkingc.print)
router.get('/refearsh',session,parkingc.ref)


module.exports=router

